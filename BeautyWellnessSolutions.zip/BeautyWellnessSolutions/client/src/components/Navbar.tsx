import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [location] = useLocation();

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link href="/">
              <a className="flex items-center">
                <span className="text-2xl font-bold text-primary">
                  Advanced BeautyMed
                </span>
                <span className="ml-2 text-sm text-gray-500">
                  Skin & Hair Clinic
                </span>
              </a>
            </Link>
          </div>

          <div className="flex space-x-8">
            <Link href="/">
              <a className={cn(
                "inline-flex items-center px-1 pt-1 text-sm font-medium",
                location === "/" ? "text-primary border-b-2 border-primary" : "text-gray-500"
              )}>
                Home
              </a>
            </Link>
            <Link href="/treatments">
              <a className={cn(
                "inline-flex items-center px-1 pt-1 text-sm font-medium",
                location === "/treatments" ? "text-primary border-b-2 border-primary" : "text-gray-500"
              )}>
                Treatments
              </a>
            </Link>
            <Link href="/contact">
              <a className={cn(
                "inline-flex items-center px-1 pt-1 text-sm font-medium",
                location === "/contact" ? "text-primary border-b-2 border-primary" : "text-gray-500"
              )}>
                Contact
              </a>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}