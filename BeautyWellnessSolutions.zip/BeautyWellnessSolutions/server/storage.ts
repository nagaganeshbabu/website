import { 
  type Treatment, 
  type InsertTreatment,
  type ContactMessage,
  type InsertContactMessage 
} from "@shared/schema";

export interface IStorage {
  getTreatments(): Promise<Treatment[]>;
  getTreatmentsByCategory(category: string): Promise<Treatment[]>;
  getTreatment(id: number): Promise<Treatment | undefined>;
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
}

export class MemStorage implements IStorage {
  private treatments: Map<number, Treatment>;
  private messages: Map<number, ContactMessage>;
  private treatmentId: number;
  private messageId: number;

  constructor() {
    this.treatments = new Map();
    this.messages = new Map();
    this.treatmentId = 1;
    this.messageId = 1;

    // Seed initial treatments
    const initialTreatments: InsertTreatment[] = [
      {
        name: "Advanced Facial Treatment",
        description: "Comprehensive facial treatment using medical-grade products",
        category: "skin",
        duration: 60,
        price: 150,
        image: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881"
      },
      {
        name: "Hair Restoration Therapy",
        description: "Advanced hair restoration using latest techniques",
        category: "hair",
        duration: 90,
        price: 200,
        image: "https://images.unsplash.com/photo-1579154341098-e4e158cc7f55"
      }
      // Add more treatments as needed
    ];

    initialTreatments.forEach(treatment => {
      const id = this.treatmentId++;
      this.treatments.set(id, { ...treatment, id });
    });
  }

  async getTreatments(): Promise<Treatment[]> {
    return Array.from(this.treatments.values());
  }

  async getTreatmentsByCategory(category: string): Promise<Treatment[]> {
    return Array.from(this.treatments.values()).filter(
      t => t.category === category
    );
  }

  async getTreatment(id: number): Promise<Treatment | undefined> {
    return this.treatments.get(id);
  }

  async createContactMessage(message: InsertContactMessage): Promise<ContactMessage> {
    const id = this.messageId++;
    const newMessage: ContactMessage = { ...message, id, processed: false };
    this.messages.set(id, newMessage);
    return newMessage;
  }
}

export const storage = new MemStorage();
