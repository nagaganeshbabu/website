import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, DollarSign } from "lucide-react";
import type { Treatment } from "@shared/schema";
import { Link } from "wouter";

interface TreatmentCardProps {
  treatment: Treatment;
}

export function TreatmentCard({ treatment }: TreatmentCardProps) {
  return (
    <Card className="overflow-hidden">
      <img
        src={treatment.image}
        alt={treatment.name}
        className="w-full h-48 object-cover"
      />
      <CardHeader>
        <CardTitle>{treatment.name}</CardTitle>
        <CardDescription>{treatment.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
          <div className="flex items-center">
            <Clock className="w-4 h-4 mr-1" />
            {treatment.duration} mins
          </div>
          <div className="flex items-center">
            <DollarSign className="w-4 h-4 mr-1" />
            {treatment.price}
          </div>
        </div>
        <Link href={`/contact?treatment=${treatment.id}`}>
          <Button className="w-full">Book Now</Button>
        </Link>
      </CardContent>
    </Card>
  );
}
