import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/treatments", async (_req, res) => {
    const treatments = await storage.getTreatments();
    res.json(treatments);
  });

  app.get("/api/treatments/category/:category", async (req, res) => {
    const treatments = await storage.getTreatmentsByCategory(req.params.category);
    res.json(treatments);
  });

  app.get("/api/treatments/:id", async (req, res) => {
    const treatment = await storage.getTreatment(parseInt(req.params.id));
    if (!treatment) {
      return res.status(404).json({ message: "Treatment not found" });
    }
    res.json(treatment);
  });

  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      const message = await storage.createContactMessage(contactData);
      res.status(201).json(message);
    } catch (error) {
      res.status(400).json({ message: "Invalid contact form data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
