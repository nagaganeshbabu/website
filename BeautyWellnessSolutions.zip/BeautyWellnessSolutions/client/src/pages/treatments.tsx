import { Layout } from "@/components/Layout";
import { TreatmentCard } from "@/components/TreatmentCard";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Treatment } from "@shared/schema";

export default function Treatments() {
  const { data: treatments } = useQuery<Treatment[]>({
    queryKey: ["/api/treatments"]
  });

  const skinTreatments = treatments?.filter(t => t.category === "skin") || [];
  const hairTreatments = treatments?.filter(t => t.category === "hair") || [];

  return (
    <Layout
      title="Our Treatments"
      description="Discover our range of advanced skin care and hair treatments at BeautyMed Clinic."
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl font-extrabold text-gray-900 text-center mb-8">
          Our Treatments
        </h1>

        <Tabs defaultValue="skin" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="skin">Skin Treatments</TabsTrigger>
            <TabsTrigger value="hair">Hair Treatments</TabsTrigger>
          </TabsList>
          
          <TabsContent value="skin">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-8">
              {skinTreatments.map((treatment) => (
                <TreatmentCard key={treatment.id} treatment={treatment} />
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="hair">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-8">
              {hairTreatments.map((treatment) => (
                <TreatmentCard key={treatment.id} treatment={treatment} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
