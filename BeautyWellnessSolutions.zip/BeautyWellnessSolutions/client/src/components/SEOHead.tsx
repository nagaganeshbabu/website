import { Helmet } from "react-helmet";

interface SEOHeadProps {
  title: string;
  description: string;
}

export function SEOHead({ title, description }: SEOHeadProps) {
  const fullTitle = `${title} | BeautyMed Clinic`;
  
  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:type" content="website" />
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "MedicalBusiness",
          "name": "BeautyMed Clinic",
          "description": description,
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "123 Medical Plaza",
            "addressLocality": "City",
            "addressRegion": "State",
            "postalCode": "12345",
            "addressCountry": "US"
          },
          "telephone": "(555) 123-4567",
          "openingHours": [
            "Mo-Fr 09:00-19:00",
            "Sa 10:00-16:00"
          ]
        })}
      </script>
    </Helmet>
  );
}
