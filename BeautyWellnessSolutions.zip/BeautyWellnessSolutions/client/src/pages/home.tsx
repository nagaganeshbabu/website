import { Layout } from "@/components/Layout";
import { Hero } from "@/components/Hero";
import { TreatmentCard } from "@/components/TreatmentCard";
import { useQuery } from "@tanstack/react-query";
import type { Treatment } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import {
  Facebook,
  Instagram,
  Twitter,
  Mail,
  Phone,
  MapPin,
} from "lucide-react";

export default function Home() {
  const { data: treatments } = useQuery<Treatment[]>({
    queryKey: ["/api/treatments"],
  });

  return (
    <Layout
      title="Advanced Skin & Hair Treatments | Advanced BeautyMed"
      description="Experience revolutionary skin and hair treatments at Advanced BeautyMed. Our expert doctors combine cutting-edge technology with proven techniques for exceptional results."
    >
      <Hero />

      {/* Treatments Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-extrabold text-gray-900 text-center mb-4">
            Tamyra Skin & Hair Clinic
          </h2>
          <p className="text-xl text-gray-600 text-center mb-8">
            Discover our comprehensive range of cutting-edge treatments
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {treatments?.map((treatment) => (
              <TreatmentCard key={treatment.id} treatment={treatment} />
            ))}
          </div>

          <div className="text-center mt-8">
            <Link href="/treatments">
              <Button size="lg">View All Treatments</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Equipment Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-extrabold text-gray-900 text-center mb-4">
            Cutting-Edge Technology
          </h2>
          <p className="text-xl text-gray-600 text-center mb-8">
            We use the latest medical-grade equipment for optimal results
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="pt-6">
                <img
                  src="https://images.unsplash.com/photo-1579684385127-1ef15d508118"
                  alt="Advanced Laser System"
                  className="rounded-lg mb-4 h-48 w-full object-cover"
                />
                <h3 className="text-xl font-semibold mb-2">
                  Advanced Laser Technology
                </h3>
                <p className="text-gray-600">
                  State-of-the-art laser systems for precise and effective
                  treatments
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <img
                  src="https://images.unsplash.com/photo-1579684453423-f84349ef60b0"
                  alt="Facial Treatment Technology"
                  className="rounded-lg mb-4 h-48 w-full object-cover"
                />
                <h3 className="text-xl font-semibold mb-2">
                  Medical-Grade Facial Systems
                </h3>
                <p className="text-gray-600">
                  Advanced diagnostic and treatment technology for optimal skin
                  health
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <img
                  src="https://images.unsplash.com/photo-1579684288402-e3e706a730b1"
                  alt="Hair Analysis System"
                  className="rounded-lg mb-4 h-48 w-full object-cover"
                />
                <h3 className="text-xl font-semibold mb-2">
                  Hair Restoration Technology
                </h3>
                <p className="text-gray-600">
                  Advanced systems for comprehensive hair analysis and treatment
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Doctors Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-extrabold text-gray-900 text-center mb-4">
            Our Expert Doctors
          </h2>
          <p className="text-xl text-gray-600 text-center mb-8">
            Meet our highly qualified medical professionals
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <Card>
              <CardContent className="pt-6">
                <img
                  src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2"
                  alt="Dr. Sudha"
                  className="rounded-full w-48 h-48 object-cover mx-auto mb-4"
                />
                <h3 className="text-2xl font-semibold text-center mb-2">
                  Dr. Sudha
                </h3>
                <p className="text-gray-600 text-center mb-2">
                  Specialist in Advanced Skin Treatments
                </p>
                <p className="text-gray-500 text-center">
                  With over 15 years of experience in medical aesthetics and
                  dermatology
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <img
                  src="https://images.unsplash.com/photo-1594824476967-48c8b964273f"
                  alt="Dr. Puja"
                  className="rounded-full w-48 h-48 object-cover mx-auto mb-4"
                />
                <h3 className="text-2xl font-semibold text-center mb-2">
                  Dr. Puja
                </h3>
                <p className="text-gray-600 text-center mb-2">
                  Expert in Hair Restoration
                </p>
                <p className="text-gray-500 text-center">
                  Specialized in advanced hair treatments and scalp health
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-extrabold text-gray-900 mb-6">
                Welcome to Advanced BeautyMed
              </h2>
              <p className="text-xl text-gray-600 mb-6">
                At Advanced BeautyMed, we combine medical expertise with
                cutting-edge technology to deliver exceptional skin and hair
                treatments. Our state-of-the-art clinic provides a luxurious and
                comfortable environment for all your aesthetic needs.
              </p>
              <p className="text-lg text-gray-500">
                With a focus on safety, innovation, and personalized care, our
                expert team creates customized treatment plans to help you
                achieve your desired results. Trust in our years of experience
                and commitment to excellence.
              </p>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1629909615184-74c4892b5958"
                alt="Modern Clinic Interior"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Contact and Social Media Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-4xl font-extrabold text-gray-900 mb-8">
                Get in Touch
              </h2>
              <div className="space-y-6">
                <div className="flex items-center">
                  <MapPin className="h-6 w-6 text-primary mr-3" />
                  <span className="text-lg">
                    123 Medical Plaza, City, State 12345
                  </span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-6 w-6 text-primary mr-3" />
                  <span className="text-lg">(555) 123-4567</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-6 w-6 text-primary mr-3" />
                  <span className="text-lg">info@advancedbeautymed.com</span>
                </div>
              </div>
              <Link href="/contact">
                <Button size="lg" className="mt-8">
                  Schedule Your Consultation
                </Button>
              </Link>
            </div>
            <div>
              <h2 className="text-4xl font-extrabold text-gray-900 mb-8">
                Connect With Us
              </h2>
              <div className="flex space-x-6">
                <a
                  href="#"
                  className="text-gray-400 hover:text-primary transition-colors"
                >
                  <Facebook className="h-10 w-10" />
                </a>
                <a
                  href="#"
                  className="text-gray-400 hover:text-primary transition-colors"
                >
                  <Instagram className="h-10 w-10" />
                </a>
                <a
                  href="#"
                  className="text-gray-400 hover:text-primary transition-colors"
                >
                  <Twitter className="h-10 w-10" />
                </a>
              </div>
              <p className="mt-6 text-lg text-gray-600">
                Follow us on social media for the latest updates, special
                offers, and beauty tips.
              </p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
